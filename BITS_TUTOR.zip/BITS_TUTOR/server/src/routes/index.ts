import authRouter from "./authRoutes";
import tutorRouter from "./tutorRoutes";
import studentRouter from "./studentRoutes";
import reviewRouter from "./reviewRoutes";

export { authRouter, tutorRouter, studentRouter, reviewRouter };
